const { createCanvas } = require('canvas');
const fs = require('fs');

function drawIcon(size) {
  const canvas = createCanvas(size, size);
  const ctx = canvas.getContext('2d');

  // Background
  ctx.fillStyle = '#0a0a0f';
  ctx.fillRect(0, 0, size, size);

  // Outer glow ring
  const glow = ctx.createRadialGradient(size/2, size/2, size*0.25, size/2, size/2, size*0.48);
  glow.addColorStop(0, 'rgba(108,99,255,0.1)');
  glow.addColorStop(1, 'rgba(108,99,255,0)');
  ctx.fillStyle = glow;
  ctx.beginPath();
  ctx.arc(size/2, size/2, size*0.48, 0, Math.PI*2);
  ctx.fill();

  // Orb
  const grad = ctx.createRadialGradient(size*0.4, size*0.35, 0, size/2, size/2, size*0.35);
  grad.addColorStop(0, '#a78bfa');
  grad.addColorStop(1, '#4338ca');
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(size/2, size/2, size*0.32, 0, Math.PI*2);
  ctx.fill();

  // Dashed ring
  ctx.strokeStyle = 'rgba(139,124,248,0.35)';
  ctx.lineWidth = size * 0.015;
  ctx.setLineDash([size*0.06, size*0.04]);
  ctx.beginPath();
  ctx.arc(size/2, size/2, size*0.42, 0, Math.PI*2);
  ctx.stroke();
  ctx.setLineDash([]);

  return canvas.toBuffer('image/png');
}

fs.mkdirSync('./icons', { recursive: true });
fs.writeFileSync('./icons/icon-192.png', drawIcon(192));
fs.writeFileSync('./icons/icon-512.png', drawIcon(512));
console.log('Icons generated!');
