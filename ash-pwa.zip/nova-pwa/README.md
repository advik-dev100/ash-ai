# Ash AI — Smart Voice Assistant PWA

A fully offline-installable Progressive Web App voice assistant powered by Claude AI.

## Features
- 🎤 Voice input (Speech Recognition)
- 🔊 Voice output (Text-to-Speech)
- 🌤 Live weather (web search)
- 😂 Jokes, facts, tips
- 🪙 Coin flip
- 🔍 Web search
- 💬 Full conversation memory (last 20 messages)
- 📱 Installable on Android, iOS, Windows, Mac

## Setup

### Option 1 — GitHub Pages (recommended)
1. Create a repo called `ash.ai` on GitHub
2. Push all files
3. Go to Settings → Pages → Deploy from main branch
4. Visit `https://advik-dev100.github.io/ash.ai/`
5. Open in Chrome on Android → tap "Add to Home Screen"

### Option 2 — Local server
```bash
npx serve .
# or
python3 -m http.server 8080
```
Then open http://localhost:8080

## Customise
- Change `CITY` in `index.html` line ~130 to your city
- Toggle TTS (🔊) in the top bar
- Clear chat (🗑) to reset conversation

## Robot conversion (Phase 2)
When you're ready to put this on a robot:
- Replace SpeechRecognition with `faster-whisper` on Raspberry Pi / Arduino Mega
- Replace TTS with `piper-tts` for offline voice
- Add `openWakeWord` for "Hey Ash" wake word
- Wire the orb animation to actual LEDs via serial port

## File structure
```
ash-pwa/
├── index.html      ← entire app
├── manifest.json   ← PWA config
├── sw.js           ← service worker (offline cache)
└── icons/
    ├── icon-192.png
    └── icon-512.png
```
